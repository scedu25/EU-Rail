class Empty(Exception):
    """Error attempting to access an element from an empty container."""
    pass
