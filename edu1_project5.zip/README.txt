README
Eric Du
edu1@stu.parkland.edu
CSC 220, Spring 2016

Description:
This project is designed to take an input file of Eurail travel times, store 
the data in an undirected, weighted graph, calculate shortest path using 
Dijkstra's Algorithm, and create an output GraphViz file of the entire 
system route map with the itinerary highlighted. This project's main focus 
is on becoming familiar with graphs.

Dependencies:
graph.py
shortest_path.py
adaptable_heap_priority_queue.py
heap_priority_queue.py
priority_queue_base.py
sanitised_input.py
TripPlanner.py
project5.py

Requirements:
- Python 3
eurail.txt

Run as:
$ python project5.py

Operation:
Enter origin/destination cities, answer y/n for quit and saving schematic.

Output:
schematic.gv file
